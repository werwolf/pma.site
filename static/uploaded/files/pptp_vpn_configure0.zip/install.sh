#!/bin/sh
if [ $4 ] && [ -z $5 ]
then
sed "s/LOGIN/$3/g" pre-conf | sed "s/SERVER/$2/g" | sed "s/PPTP/$1/g" > /etc/ppp/peers/$1
echo "$3 * $4" >> /etc/ppp/chap-secrets
echo "$2 $1" >> /etc/hosts
echo "USAGE: sudo pon/poff NAME"
else
echo "USAGE: sudo ./install.sh NAME SERVER LOGIN PASSWORD"
fi
